/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


/**
 *
 * @author imaat
 */
public class AddTeacher {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/scldb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

        
    

    public void addTeacher(int teacherId, String teacherName, String subject, int contact, String gender) throws SQLException {
       String query = "INSERT INTO teacher (teacherId, teacherName, subject , contact, gender) VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, teacherId);
            statement.setString(2, teacherName);
            statement.setString(3, subject);
            statement.setInt(4, contact);
            statement.setString(5, gender);
           

            statement.executeUpdate();
        } catch (SQLException e) {
            throw new SQLException("Error adding student: " + e.getMessage());
        }
    }
}
    

