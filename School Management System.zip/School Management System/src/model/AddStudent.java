/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author imaat
 */
public class AddStudent {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/scldb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    
        
    

    public void addStudent(int studentId, String studentName, String gender, String address, int contact) throws SQLException {
        String query = "INSERT INTO student (studentId, studentName, gender , address, contact) VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, studentId);
            statement.setString(2, studentName);
            statement.setString(3, gender);
            statement.setString(4, address);
            statement.setInt(5, contact);
           

            statement.executeUpdate();
        } catch (SQLException e) {
            throw new SQLException("Error adding student: " + e.getMessage());
        }
    }

}
