/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 *
 * @author imaat
 */
public class RemoveAdmin {
    public static void removeAdmin(String username) throws SQLException {
        String sql = "DELETE FROM login WHERE Username = ?";

        try (Connection conn = DBConnection.getConnection(); 
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("No account found with account number: " + username);
            }
        } catch (SQLException e) {
            throw new SQLException("Error removing account: " + e.getMessage(), e);
        }
    }

}
