/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author imaat
 */
public class RemoveTeacher {

    public static void removeTeacher(int teacherId) throws SQLException {
         String sql = "DELETE FROM teacher WHERE teacherId = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, teacherId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("No account found with student number: " + teacherId);
            }
        } catch (SQLException e) {
            throw new SQLException("Error removing teacher " + e.getMessage(), e);
        }
    }
}

