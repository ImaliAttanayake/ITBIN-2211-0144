/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.SQLException;
import model.AddStudent;
import model.RemoveStudent;

/**
 *
 * @author imaat
 */
public class StudentController {
    public static void addStudent(int studentId, String studentName, String gender,
                                  String address, int contact)
                 throws SQLException {
        AddStudent addStudent = new AddStudent();
        addStudent.addStudent(studentId, studentName, gender, address,contact);
    }
    public void removeStudent(int studentId) throws SQLException {
        RemoveStudent.removeStudent(studentId);
}
}
    

         
         
