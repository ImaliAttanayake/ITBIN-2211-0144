/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.SQLException;
import model.AddTeacher;
import model.RemoveTeacher;
import view.RemoveTeacherForm;
/**
 *
 * @author imaat
 */
public class TeacherController {
    
    public static void addTeacher(int teacherId, String teacherName, String subject,
                                  int contact, String gender)
                 throws SQLException {
        AddTeacher addTeacher = new AddTeacher();
        addTeacher.addTeacher(teacherId, teacherName, subject, contact, gender);
    }
     public void removeTeacher(int teacherId) throws SQLException {
        RemoveTeacher.removeTeacher(teacherId);
}
}

